

<?php $__env->startSection('title', 'Deatails for ' . $purchase->name); ?>

<?php $__env->startSection('content'); ?>
    <h1> Deatails for <?php echo e($purchase->name); ?> </h1>

    <form action="<?php echo e(route('purchase.destroy', ['purchase' => $purchase])); ?>" method="POST">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>

        <button type="submit" class="btn btn-danger"> Delete </button>
    </form>
    
 </br>

    <?php echo e($purchase->created_at); ?>


    <table class="table table-bordered">

        <thead>
            <tr>
               <th>Purchase ID</th>
                <th>Account Name</th>
               <th> Address</th> 
               <th> Contact Person</th>  
               <th> Contact #</th>  
               <th> Type</th>   
                
            </tr>
        </thead>

        <tbody>
             
            <tr>
                <td><?php echo e($purchase->id); ?></td>
                <td><?php echo e($purchase->name); ?></td>
                <td><?php echo e($purchase->address); ?></td>
                <td><?php echo e($purchase->contact); ?></td>
                <td><?php echo e($purchase->phone); ?></td>
                <td><?php echo e($purchase->type); ?></td>
                

            </tr>
           
        </tbody>
    </table>

    <table width="50%" border="3" cellpadding="0" cellspacing="0" class="tabla">
        <tr>
        <th style=" background-color:#4CAF50;">Product</th>
        <th style=" background-color:#4CAF50;">Amount</th>
        <th style=" background-color:#4CAF50;">Price</th>
        </tr>

        <tr style=" background-color:white;">
        <td><?php echo e($purchase->product); ?></td>
        <td><?php echo e($purchase->amount); ?></td>
        <td><?php echo e($purchase->price); ?></td>
        </tr>

        <tr style=" background-color:white;">
        <td><?php echo e($purchase->product2); ?></td>
        <td><?php echo e($purchase->amount2); ?></td>
        <td><?php echo e($purchase->price2); ?></td>
        </tr>

        <tr style=" background-color:white;">
        <td><?php echo e($purchase->product3); ?></td>
        <td><?php echo e($purchase->amount3); ?></td>
        <td><?php echo e($purchase->price3); ?></td>
        </tr>

        <tr style=" background-color:white;">
        <td><?php echo e($purchase->product4); ?></td>
        <td><?php echo e($purchase->amount4); ?></td>
        <td><?php echo e($purchase->price4); ?></td>
        </tr>

        <tr style=" background-color:white;">
        <td><?php echo e($purchase->product5); ?></td>
        <td><?php echo e($purchase->amount5); ?></td>
        <td><?php echo e($purchase->price5); ?></td>
        </tr>

        <tr style=" background-color:white;">
        <td><?php echo e($purchase->product6); ?></td>
        <td><?php echo e($purchase->amount6); ?></td>
        <td><?php echo e($purchase->price6); ?></td>
        </tr>

        <tr style=" background-color:white;">
        <td><?php echo e($purchase->product7); ?></td>
        <td><?php echo e($purchase->amount7); ?></td>
        <td><?php echo e($purchase->price7); ?></td>
        </tr>

        <tr style=" background-color:white;">
        <td><?php echo e($purchase->product8); ?></td>
        <td><?php echo e($purchase->amount8); ?></td>
        <td><?php echo e($purchase->price8); ?></td>
        </tr>

        <tr style=" background-color:white;">
        <td><?php echo e($purchase->product9); ?></td>
        <td><?php echo e($purchase->amount9); ?></td>
        <td><?php echo e($purchase->price9); ?></td>
        </tr>

        <tr style=" background-color:white;">
        <td><?php echo e($purchase->product10); ?></td>
        <td><?php echo e($purchase->amount10); ?></td>
        <td><?php echo e($purchase->price10); ?></td>
        </tr>

        <tr style=" background-color:white;">
        <td></td>
        <td>Total:</td>
        <td><?php echo e($purchase->total); ?></td>
        </tr>

        </table>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\laravel-6-beginner\resources\views/purchase/show.blade.php ENDPATH**/ ?>