

<?php $__env->startSection('title', 'Product'); ?>

<?php $__env->startSection('content'); ?>
    <h1> Products </h1>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Product::class)): ?>
    <p><a href="<?php echo e(route('product.create')); ?>"> <button class="btn btn-primary">Add Product</button> </a></p>
    <?php endif; ?>
<table class="table table-bordered">

        <thead>
            <tr>
               <th> ID</th>
                <th>Generic Name</th>
               <th> Brand Name</th>
               <th> Stock</th>  
               <?php if(Auth::user()->name === 'Admin'): ?>
                   <th> Options</th>    
               <?php else: ?>
                   
               <?php endif; ?>
               
            </tr>
        </thead>

        <tbody>
             <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
    
               <td> <?php echo e($product->id); ?></td>
                <td><a href="<?php echo e(route('product.show', ['product' => $product])); ?>"><?php echo e($product->gname); ?></a></td>
               <td><a href="<?php echo e(route('product.show', ['product' => $product])); ?>"><?php echo e($product->bname); ?></a></td>
               <td><?php echo e($product->qty); ?></td>
               
                <?php if(Auth::user()->name === 'Admin'): ?>
                    <td>
                   <div class="input-group">
                    <p><a href="<?php echo e(route('product.edit', ['product' => $product])); ?>">
                    <button class="btn btn-primary"> Edit</button> </a></p>
                    <span class="input-group-btn">
                    <form action="<?php echo e(route('product.destroy', ['product' => $product])); ?>" method="POST">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>

                    <button type="submit" class="btn btn-danger"> Delete </button> 
                    </form>
                    </span>
                    </div>
                    </td>
                <?php else: ?>
                    
                <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\laravel-6-beginner\resources\views/product/index.blade.php ENDPATH**/ ?>