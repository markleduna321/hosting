

<?php $__env->startSection('title', 'Edit Details for ' . $purchase->name); ?>

<?php $__env->startSection('content'); ?>
    <h1> Edit Details for <?php echo e($purchase->name); ?> </h1>

    <form action="<?php echo e(route('purchase.update', ['purchase' => $purchase])); ?>" method="POST" enctype="multipart/form-data" class="pb-3">
        <?php echo method_field('PATCH'); ?>
        <?php echo $__env->make('purchase.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
        <button type="submit" class="btn btn-primary">Update Order</button>

    </form>

    <hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\laravel-6-beginner\resources\views/purchase/edit.blade.php ENDPATH**/ ?>