

<?php $__env->startSection('title', 'About'); ?>

<?php $__env->startSection('content'); ?>
    <h1> product </h1>
    <p><a href="<?php echo e(route('productinv.create')); ?>"> <button class="btn btn-primary">Add product</button> </a></p>

    <div class="row">
            <div class="col-2">
                <b>Generic Name</b>
            </div>
            <div class="col-2">
               <b> EXP. Date</b>
            </div>
            <div class="col-1">
                <b>QTY Left</b>
            </div>
            <div class="col-1">
                <b>QTY</b>
            </div>
            <div class="col-1">
                <b>Location</b>
            </div>
            <div class="col-1">
               <b>Unit Price </b>
            </div>
            <div class="col-1">
               <b>Unit Total </b>
            </div>
            <div class="col-1">
               <b> Price </b>
            </div>
            <div class="col-2">
               <b>Total</b>
            </div>
    </div>

    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div class="row">
            <div class="col-2">
               <a href="<?php echo e(route('productinv.show', ['productinv' => $product])); ?>"> <?php echo e($product->name); ?> </a>
            </div>
            <div class="col-2">
               <?php echo e($product->expdate); ?>

            </div>
            <div class="col-1">
                <?php echo e($product->qtyleft); ?>

            </div>
            <div class="col-1">
                <?php echo e($product->qty); ?>

            </div>
            <div class="col-1">
                <?php echo e($product->location); ?>

            </div>
            <div class="col-1">
               <?php echo e($product->unitprice); ?>

            </div>
             <div class="col-1">
               <?php echo e($product->totalunit); ?>

            </div>
            <div class="col-1">
               <?php echo e($product->price); ?>

            </div>
            <div class="col-2">
               <?php echo e($product->total); ?>

            </div>
            
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\laravel-6-beginner\resources\views/productinv/index.blade.php ENDPATH**/ ?>