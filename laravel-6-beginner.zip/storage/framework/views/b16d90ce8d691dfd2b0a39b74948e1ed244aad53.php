<table class="table table-bordered">

        <thead>
            <tr>
               <th>Purchase ID</th>
                <th>Account Name</th>
               <th> Address</th> 
               <th> Type</th>   
               <th> Status</th>    
            </tr>
        </thead>

        <tbody>
             <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($purchase->id); ?></td>
                <td><a href="<?php echo e(route('purchase.show', ['purchase' => $purchase])); ?>"><?php echo e($purchase->name); ?></a></td>
                <td><?php echo e($purchase->address); ?></td>
                <td><?php echo e($purchase->type); ?></td>
                <td><?php echo e($purchase->status); ?></td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php /**PATH C:\Users\User\laravel-6-beginner\resources\views/accept/index.blade.php ENDPATH**/ ?>