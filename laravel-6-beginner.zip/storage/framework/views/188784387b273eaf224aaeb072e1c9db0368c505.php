<?php $__env->startSection('title', 'About'); ?>

<?php $__env->startSection('content'); ?>
    <h1> home </h1>
<?php $__env->stopSection(); ?>

afad
<?php

namespace App\Http\Controllers;

use App\Models\Inventory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class InventoryController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $inventories = Inventory::all();

        return view('inventory.index', compact('inventories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $inventory = new Inventory();

        return view('inventory.create', compact('inventory'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {      
        
        $inventory = Inventory::create($this->validateRequest());
        $this->storeImage($inventory);

        return redirect('inventory');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Inventory  $inventory
     * @return \Illuminate\Http\Response
     */
    public function show(Inventory $inventory)
    {
        //$this->authorize('view', $inventory);

        return view('inventory.show', compact('inventory'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Inventory  $inventory
     * @return \Illuminate\Http\Response
     */
    public function edit(Inventory $inventory)
    {
        return view('inventory.edit', compact('inventory'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Inventory  $inventory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Inventory $inventory)
    {
        $inventory->update($this->validateRequest());

        $this->storeImage($inventory);

        return redirect('inventory/' . $inventory->id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Inventory  $inventory
     * @return \Illuminate\Http\Response
     */
    public function destroy(Inventory $inventory)
    {
        $inventory->delete();

        return redirect('inventory');
    }

    private function validateRequest(){

        return request()->validate([
            'gname' => 'required|min:3',
            'bname' => 'required',
            'image' => 'sometimes|file|image|max:7000',
        ]);
    }

    public function storeImage($inventory){

        if (request()->has('image')){

            $inventory->update([

                'image' => request()->image->store('uploads', 'public'),
            ]);
        }
    }
}

public function getTotalAttribute($value)
    {
        return $value;
    }







<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Inventory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products = Product::all();

        return view('product.index', compact('products'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $inventories = Inventory::all();
        $product = new Product();

        return view('product.create', compact('product', 'inventories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request['totalunit'] = $request->unitprice * $request->qty;
        $request['total'] = $request->price * $request->qty; 
        
        $request['qtyleft'] = $request->totalqty - $request->qty; 
        Product::create($this->validateRequest());

        return redirect('product');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        return view('product.show', compact('product'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        $inventories = Inventory::all();

        return view('product.edit', compact('product', 'inventories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        $request['totalunit'] = $request->unitprice * $request->qty; 
        $request['total'] = $request->price * $request->qty; 
        $request['qtyleft'] = $request->qtyleft - $request->qty; 
        $product->update($this->validateRequest());

        //$this->storeImage($customer);

        return redirect('product/' . $product->id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        $product->delete();

        return redirect('product');
    }

    private function validateRequest(){

        return request()->validate([
            'name' => 'required',
            'expdate' => 'required',
            'totalqty' => 'sometimes',
            'qtyleft' => 'sometimes',
            'location' => 'required',
            'qty' => 'required',
            'unitprice' => 'required',
            'price' => 'required',
            'totalunit' => 'required',
            'total' => 'required',
        ]);
    }
}

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\laravel-6-beginner\resources\views/welcome.blade.php ENDPATH**/ ?>