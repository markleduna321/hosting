    <?php echo csrf_field(); ?>
        <div class="form-group pb-3">
            <label for="name">Product Name:</label>
            <select name="name" id="name" class="form-control">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->gname); ?> -- <?php echo e($product->bname); ?>" <?php echo e($product->id == $product->gname ? 'selected' : ''); ?>> <?php echo e($product->gname); ?> -- <?php echo e($product->bname); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <div><?php echo e($errors->first('name')); ?></div>
        </div>

        <div class="form-group pb-3">
            <label for="expdate">EXP. Date:</label>
            <input type="date" name="expdate" value="<?php echo e(old('expdate')); ?>" class="form-control">
            <div><?php echo e($errors->first('expdate')); ?></div>
        </div>

        <div class="form-group pb-3">
            <label for="qtyleft">QTY. Left:</label>
            <input type="number" name="qtyleft" value="<?php echo e(old('qtyleft')); ?>" class="form-control">
            <div><?php echo e($errors->first('qtyleft')); ?></div>
        </div>

        <div class="form-group pb-3">
            <label for="qty">QTY.:</label>
            <input type="number" name="qty" value="<?php echo e(old('qty')); ?>" class="form-control">
            <div><?php echo e($errors->first('qty')); ?></div>
        </div>

        <div class="form-group pb-3">
            <label for="location">Location:</label>
            <select name="location" id="location" class="form-control">
                    <option value="Hospital"> Hospital </option>
                    <option value="Pharmacy"> Pharmacy </option>
            </select>
            <div><?php echo e($errors->first('location')); ?></div>
        </div>

        <div class="form-group pb-3">
            <label for="unitprice">Unit Price:</label>
            <input type="number" name="unitprice" value="<?php echo e(old('unitprice')); ?>" class="form-control">
            <div><?php echo e($errors->first('unitprice')); ?></div>
        </div>  
            
        <div class="form-group pb-3">
            <label for="price">Price:</label>
            <input type="number" name="price" value="<?php echo e(old('price')); ?>" class="form-control">
            <div><?php echo e($errors->first('price')); ?></div>
        </div>  

    <?php /**PATH C:\Users\User\laravel-6-beginner\resources\views/productinv/form.blade.php ENDPATH**/ ?>