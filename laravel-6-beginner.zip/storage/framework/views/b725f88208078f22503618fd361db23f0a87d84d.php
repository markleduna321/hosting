    <?php echo csrf_field(); ?>
       
            Account Name: 
            <input type="text" name="name" value="<?php echo e($inventory->name); ?>"  style="border:0; font-size:16px;width:350px;" readonly>

            Date: 
            <input type="text" name="" value="<?php echo e($inventory->created_at); ?>"  style="border:0; font-size:16px;width:350px;" readonly>
            <br>
            Address: 
            <input type="text" name="address" value="<?php echo e($inventory->address); ?>"  style="border:0; font-size:16px;width:350px;" readonly>
            <input type="hidden" name="status" value="Completed">
            <input type="hidden" name="id" value="<?php echo e($inventory->id); ?>">
        <table border="3" cellpadding="0" cellspacing="0" class="tabla">
        <tr>
        <th style=" background-color:#4CAF50;">Product</th>
        <th style=" background-color:#4CAF50;">END INV</th>
        <th style=" background-color:#4CAF50;">New Delivery</th>
        <th style=" background-color:#4CAF50;">DR/INV #</th>
        <th style=" background-color:#4CAF50;">Total Stocks</th>
        <th style=" background-color:#4CAF50;">Stocks On Hand</th>
        <th style=" background-color:#4CAF50;">Stocks Sold</th>
        <th style=" background-color:#4CAF50;">Price</th>
        <th style=" background-color:#4CAF50;">Amount</th>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;" name="product" value="<?php echo e($inventory->product); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="endinv" value="<?php echo e($inventory->endinv); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel" value="<?php echo e($inventory->newdel); ?>"></td>
        <td><input type="text" style="border:0; font-size:16px;" name="invnum" value="<?php echo e($inventory->invnum); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="totalstock" value="<?php echo e($inventory->totalstock); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stockleft" value="<?php echo e($inventory->stockleft); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stocksold" value="<?php echo e($inventory->stocksold); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price" value="<?php echo e($inventory->price); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="amount" value="<?php echo e($inventory->amount); ?>"></td>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;" name="product2" value="<?php echo e($inventory->product2); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="endinv2" value="<?php echo e($inventory->endinv2); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel2" value="<?php echo e($inventory->newdel2); ?>"></td>
        <td><input type="text" style="border:0; font-size:16px;" name="invnum2" value="<?php echo e($inventory->invnum2); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="totalstock2" value="<?php echo e($inventory->totalstock2); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stockleft2" value="<?php echo e($inventory->stockleft2); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stocksold2" value="<?php echo e($inventory->stocksold2); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price2" value="<?php echo e($inventory->price2); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="amount2" value="<?php echo e($inventory->amount2); ?>"></td>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;" name="product3" value="<?php echo e($inventory->product3); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="endinv3" value="<?php echo e($inventory->endinv3); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel3" value="<?php echo e($inventory->newdel3); ?>"></td>
        <td><input type="text" style="border:0; font-size:16px;" name="invnum3" value="<?php echo e($inventory->invnum3); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="totalstock3" value="<?php echo e($inventory->totalstock3); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stockleft3" value="<?php echo e($inventory->stockleft3); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stocksold3" value="<?php echo e($inventory->stocksold3); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price3" value="<?php echo e($inventory->price3); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="amount3" value="<?php echo e($inventory->amount3); ?>"></td>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;" name="product4" value="<?php echo e($inventory->product4); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="endinv4" value="<?php echo e($inventory->endinv4); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel4" value="<?php echo e($inventory->newdel4); ?>"></td>
        <td><input type="text" style="border:0; font-size:16px;" name="invnum4" value="<?php echo e($inventory->invnum4); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="totalstock4" value="<?php echo e($inventory->totalstock4); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stockleft4" value="<?php echo e($inventory->stockleft4); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stocksold4" value="<?php echo e($inventory->stocksold4); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price4" value="<?php echo e($inventory->price4); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="amount4" value="<?php echo e($inventory->amount4); ?>"></td>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;" name="product5" value="<?php echo e($inventory->product5); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="endinv5" value="<?php echo e($inventory->endinv5); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel5" value="<?php echo e($inventory->newdel5); ?>"></td>
        <td><input type="text" style="border:0; font-size:16px;" name="invnum5" value="<?php echo e($inventory->invnum5); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="totalstock5" value="<?php echo e($inventory->totalstock5); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stockleft5" value="<?php echo e($inventory->stockleft5); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stocksold5" value="<?php echo e($inventory->stocksold5); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price5" value="<?php echo e($inventory->price5); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="amount5" value="<?php echo e($inventory->amount5); ?>"></td>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;" name="product6" value="<?php echo e($inventory->product6); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="endinv6" value="<?php echo e($inventory->endinv6); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel6" value="<?php echo e($inventory->newdel6); ?>"></td>
        <td><input type="text" style="border:0; font-size:16px;" name="invnum6" value="<?php echo e($inventory->invnum6); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="totalstock6" value="<?php echo e($inventory->totalstock6); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stockleft6" value="<?php echo e($inventory->stockleft6); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stocksold6" value="<?php echo e($inventory->stocksold6); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price6" value="<?php echo e($inventory->price6); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="amount6" value="<?php echo e($inventory->amount6); ?>"></td>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;" name="product7" value="<?php echo e($inventory->product7); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="endinv7" value="<?php echo e($inventory->endinv7); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel7" value="<?php echo e($inventory->newdel7); ?>"></td>
        <td><input type="text" style="border:0; font-size:16px;" name="invnum7" value="<?php echo e($inventory->invnum7); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="totalstock7" value="<?php echo e($inventory->totalstock7); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stockleft7" value="<?php echo e($inventory->stockleft7); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stocksold7" value="<?php echo e($inventory->stocksold7); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price7" value="<?php echo e($inventory->price7); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="amount7" value="<?php echo e($inventory->amount7); ?>"></td>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;" name="product8" value="<?php echo e($inventory->product8); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="endinv8" value="<?php echo e($inventory->endinv8); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel8" value="<?php echo e($inventory->newdel8); ?>"></td>
        <td><input type="text" style="border:0; font-size:16px;" name="invnum8" value="<?php echo e($inventory->invnum8); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="totalstock8" value="<?php echo e($inventory->totalstock8); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stockleft8" value="<?php echo e($inventory->stockleft8); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stocksold8" value="<?php echo e($inventory->stocksold8); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price8" value="<?php echo e($inventory->price8); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="amount8" value="<?php echo e($inventory->amount8); ?>"></td>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;" name="product9" value="<?php echo e($inventory->product9); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="endinv9" value="<?php echo e($inventory->endinv9); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel9" value="<?php echo e($inventory->newdel9); ?>"></td>
        <td><input type="text" style="border:0; font-size:16px;" name="invnum9" value="<?php echo e($inventory->invnum9); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="totalstock9" value="<?php echo e($inventory->totalstock9); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stockleft9" value="<?php echo e($inventory->stockleft9); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stocksold9" value="<?php echo e($inventory->stocksold9); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price9" value="<?php echo e($inventory->price9); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="amount9" value="<?php echo e($inventory->amount9); ?>"></td>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;" name="product10" value="<?php echo e($inventory->product10); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="endinv10" value="<?php echo e($inventory->endinv10); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel10" value="<?php echo e($inventory->newdel10); ?>"></td>
        <td><input type="text" style="border:0; font-size:16px;" name="invnum10" value="<?php echo e($inventory->invnum10); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="totalstock10" value="<?php echo e($inventory->totalstock10); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stockleft10" value="<?php echo e($inventory->stockleft10); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stocksold10" value="<?php echo e($inventory->stocksold10); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price10" value="<?php echo e($inventory->price10); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="amount10" value="<?php echo e($inventory->amount10); ?>"></td>
        </tr>

        <tr>
        <th colspan="8" style="text-align:center;">Total:</th>
        <th></th>
        </tr>

        </table>
       
<?php /**PATH C:\Users\User\laravel-6-beginner\resources\views/inventory/form.blade.php ENDPATH**/ ?>