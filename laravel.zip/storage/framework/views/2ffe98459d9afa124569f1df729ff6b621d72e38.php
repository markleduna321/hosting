

<?php $__env->startSection('title', 'Deatails for ' . $products->name); ?>

<?php $__env->startSection('content'); ?>
    <h1> Deatails for <?php echo e($products->name); ?> </h1>

    <p><a href="<?php echo e(route('productinv.edit', ['productinv' => $products])); ?>"> Edit </a></p>
    <form action="<?php echo e(route('productinv.destroy', ['productinv' => $products])); ?>" method="POST">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>

        <button type="submit" class="btn btn-danger"> Delete </button>
    </form>
    <div class="row">
        <div class="col-12">
            <p><strong>Name : </strong> <?php echo e($products->name); ?> </p>
            <p><strong>Price : </strong> <?php echo e($products->qty); ?> </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\laravel-6-beginner\resources\views/productinv/show.blade.php ENDPATH**/ ?>