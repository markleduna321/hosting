

<?php $__env->startSection('title', 'Deatails for ' . $product->gname); ?>

<?php $__env->startSection('content'); ?>
    <h1> Deatails for <?php echo e($product->gname); ?> </h1>
    <?php if(Auth::user()->name === 'Admin'): ?>
        <a href="<?php echo e(route('product.edit', ['product' => $product])); ?>"> 
    <button class="btn btn-primary">Edit </button> </a>
    <form action="<?php echo e(route('product.destroy', ['product' => $product])); ?>" method="POST">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>

        <button type="submit" class="btn btn-danger"> Delete </button>
    </form>
    <?php else: ?>
        
    <?php endif; ?>
 
    <div class="row">
        <div class="col-12">
            <p><strong>Generic Name : </strong> <?php echo e($product->gname); ?> </p>
            <p><strong>Brand Name : </strong> <?php echo e($product->bname); ?> </p>  
            <p><strong>Stock : </strong> <?php echo e($product->qty); ?> </p>  
            <p><strong>New Stock : </strong> <?php echo e($product->newqty); ?> </p>  
            <p><strong>Last Delivery: </strong> <?php echo e($product->productorder); ?> </p>  
        </div>
    </div>

    <?php if($product->image): ?>
        <div class="row">
        <div class="col-12">
            <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="" class="img-thumbnail">
        </div>
        <div class="col-12">
            <img src="<?php echo e(asset('storage/' . $product->image2)); ?>" alt="" class="img-thumbnail">
        </div>
        <div class="col-12">
            <img src="<?php echo e(asset('storage/' . $product->image3)); ?>" alt="" class="img-thumbnail">
        </div>
        <div class="col-12">
            <img src="<?php echo e(asset('storage/' . $product->image4)); ?>" alt="" class="img-thumbnail">
        </div>
        <div class="col-12">
            <img src="<?php echo e(asset('storage/' . $product->image5)); ?>" alt="" class="img-thumbnail">
        </div>
        <div class="col-12">
            <img src="<?php echo e(asset('storage/' . $product->image6)); ?>" alt="" class="img-thumbnail">
        </div>
        <div class="col-12">
            <img src="<?php echo e(asset('storage/' . $product->image7)); ?>" alt="" class="img-thumbnail">
        </div>
        <div class="col-12">
            <img src="<?php echo e(asset('storage/' . $product->image8)); ?>" alt="" class="img-thumbnail">
        </div>
        <div class="col-12">
            <img src="<?php echo e(asset('storage/' . $product->image9)); ?>" alt="" class="img-thumbnail">
        </div>
        <div class="col-12">
            <img src="<?php echo e(asset('storage/' . $product->image10)); ?>" alt="" class="img-thumbnail">
        </div>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\laravel-6-beginner\resources\views/product/show.blade.php ENDPATH**/ ?>