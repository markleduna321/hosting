

<?php $__env->startSection('title', 'About'); ?>

<?php $__env->startSection('content'); ?>
    
        <h1> Inventory </h1>
    
    

<table class="table table-bordered">

        <thead>
            <tr>
               <th>Inventory ID</th>
                <th>Account Name</th>
               <th> Address</th> 
               <th> Contact #</th>  
               <th> Type</th>   
               <th> Status</th>   
               <th> Action</th>    
            </tr>
        </thead>

        <tbody>
             <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($inventory->id); ?></td>
                <td><a href="<?php echo e(route('inventory.show', ['inventory' => $inventory])); ?>"><?php echo e($inventory->name); ?></a></td>
                <td><?php echo e($inventory->address); ?></td>
                <td><?php echo e($inventory->phone); ?></td>
                <td><?php echo e($inventory->type); ?></td>
                <td><?php echo e($inventory->status); ?></a></td>
                <td>
                <?php if(Auth::user()->name === 'Admin'): ?>
                    <a href="<?php echo e(route('inventory.edit', ['inventory' => $inventory])); ?>"> 
                    <button class="btn btn-primary">Complete Process </button>
                <?php elseif($inventory->status === 'Processed'): ?>
                    <a href="<?php echo e(route('inventory.edit', ['inventory' => $inventory])); ?>"> 
                    <button class="btn btn-primary" disabled>Update Inventory</button>
                <?php else: ?>
                    <a href="<?php echo e(route('inventory.edit', ['inventory' => $inventory])); ?>"> 
                    <button class="btn btn-primary">Update Inventory</button> 
                <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php echo e($inventories->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\laravel-6-beginner\resources\views/inventory/index.blade.php ENDPATH**/ ?>