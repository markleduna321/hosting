

<?php $__env->startSection('title', 'Edit Details for ' . $product->gname); ?>

<?php $__env->startSection('content'); ?>
    <h1> Edit Details for <?php echo e($product->gname); ?> </h1>

    <form action="<?php echo e(route('product.update', ['product' => $product])); ?>" method="POST" enctype="multipart/form-data" class="pb-3">
        <?php echo method_field('PATCH'); ?>
        <?php echo $__env->make('product.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
        <button type="submit" class="btn btn-primary">Save Product</button>

    </form>

    <hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\laravel-6-beginner\resources\views/product/edit.blade.php ENDPATH**/ ?>