

<?php $__env->startSection('title', 'Add New Customer'); ?>

<?php $__env->startSection('content'); ?>
    <h1> Accept Order</h1>

    <div class="form-group pb-3">
        <form action="/searches" method="get">
            <label for="search">Generate PO Data:</label>
            <div class="input-group">
                <input type="search" name="search" class="form-control">
                    <span class="input-group-btn">
                        <button type="submit" class="btn btn-primary">Generate</button>
                    </span>
            </div>
        </form>    
        </div>
    
               
    <form action="<?php echo e(route('accept.store')); ?>" method="POST" enctype="multipart/form-data" class="pb-3">
       <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <?php echo csrf_field(); ?>

            <input type="hidden" name="user_email" value="<?php echo e($purchase->user_email); ?>" class="form-control" readonly>
       
            <input type="hidden" name="id" value="<?php echo e($purchase->id); ?>" class="form-control" readonly>
        
        <div class="form-group pb-3">
            <label for="name">Account Name:</label>
            <input type="text" name="name" value="<?php echo e($purchase->name); ?>" class="form-control" readonly>
            <div><?php echo e($errors->first('name')); ?></div>
        </div>
        <div class="form-group pb-3">
            <label for="address">Address:</label>
            <input type="text" name="address" value="<?php echo e($purchase->address); ?>" class="form-control" readonly>
            <div><?php echo e($errors->first('address')); ?></div>
        </div>

        <div class="form-group pb-3">
            <label for="type">Type:</label>
            <input type="text" name="type" value="<?php echo e($purchase->type); ?>" class="form-control" readonly>
            <div><?php echo e($errors->first('type')); ?></div>
        </div>
        
        <div class="form-group pb-3">
            <label for="conact">Contact Person:</label>
            <input type="text" name="contact" value="<?php echo e($purchase->contact); ?> " class="form-control" readonly>
            <div><?php echo e($errors->first('contact')); ?></div>
        </div>

        <div class="form-group pb-3">
            <label for="phone">Contact #:</label>
            <input type="text" name="phone" value="<?php echo e($purchase->phone); ?>" class="form-control" readonly>
            <div><?php echo e($errors->first('phone')); ?></div>
        </div>

        <div class="form-group pb-3">
            <label for="status">Status:</label>
            <input type="text" name="status" value="Processed" class="form-control" readonly>
            <div><?php echo e($errors->first('status')); ?></div>
        </div>

        <table width="50%" border="3" cellpadding="0" cellspacing="0" class="tabla"   style="position:relative;left:50px;">
        <tr>
        <th style=" background-color:#4CAF50;">Product</th>
        <th style=" background-color:#4CAF50;">amount</th>
        <th style=" background-color:#4CAF50;">Price</th>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;width:350px;" name="product" value="<?php echo e($purchase->product); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel" value="<?php echo e($purchase->amount); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price" value="<?php echo e($purchase->price); ?>" readonly></td>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;width:350px;" name="product2" value="<?php echo e($purchase->product2); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel2" value="<?php echo e($purchase->amount2); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price2" value="<?php echo e($purchase->price2); ?>" readonly></td>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;width:350px;" name="product3" value="<?php echo e($purchase->product3); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel3" value="<?php echo e($purchase->amount3); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price3" value="<?php echo e($purchase->price3); ?>" readonly></td>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;width:350px;" name="product4" value="<?php echo e($purchase->product4); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel4" value="<?php echo e($purchase->amount4); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price4" value="<?php echo e($purchase->price4); ?>" readonly></td>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;width:350px;" name="product5" value="<?php echo e($purchase->product5); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel5" value="<?php echo e($purchase->amount5); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price5" value="<?php echo e($purchase->price5); ?>" readonly></td>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;width:350px;" name="product6" value="<?php echo e($purchase->product6); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel6" value="<?php echo e($purchase->amount6); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price6" value="<?php echo e($purchase->price6); ?>" readonly></td>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;width:350px;" name="product7" value="<?php echo e($purchase->product7); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel7" value="<?php echo e($purchase->amount7); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price7" value="<?php echo e($purchase->price7); ?>" readonly></td>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;width:350px;" name="product8" value="<?php echo e($purchase->product8); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel8" value="<?php echo e($purchase->amount8); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price8" value="<?php echo e($purchase->price8); ?>" readonly></td>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;width:350px;" name="product9" value="<?php echo e($purchase->product9); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel9" value="<?php echo e($purchase->amount9); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price9" value="<?php echo e($purchase->price9); ?>" readonly></td>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;width:350px;" name="product10" value="<?php echo e($purchase->product10); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel10" value="<?php echo e($purchase->amount10); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price10" value="<?php echo e($purchase->price10); ?>" readonly></td>
        </tr>

        <tr>
        <th></th>
        <th>Total</th>
        <th><input type="number" style="border:0; font-size:16px;" name="total" value="<?php echo e($purchase->total); ?>" readonly></th>
        </tr>

        </table>

            
        <button type="submit" class="btn btn-primary">Accept Order</button>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </form>

   

   <table class="table table-bordered">

        <thead>
            <tr>
               <th>Purchase ID</th>
                <th>Account Name</th>
               <th> Address</th> 
               <th> Type</th>   
               <th> Status</th>    
            </tr>
        </thead>

        <tbody>
             <?php $__currentLoopData = $lemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lemon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <?php if($lemon->status === 'Pending'): ?>
                <td><?php echo e($lemon->id); ?></td>
                <td><?php echo e($lemon->name); ?></a></td>
                <td><?php echo e($lemon->address); ?></td>
                <td><?php echo e($lemon->type); ?></td>
                <td><?php echo e($lemon->status); ?></td>
            <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\laravel-6-beginner\resources\views/accept/create.blade.php ENDPATH**/ ?>