

<?php $__env->startSection('title', 'Add New Customer'); ?>

<?php $__env->startSection('content'); ?>
    <h1> New Inventory </h1>
<form action="<?php echo e(route('newmonth.store')); ?>" method="POST" enctype="multipart/form-data" class="pb-3">
            
    <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo csrf_field(); ?>

<input type="text" name="user_email" value="<?php echo e($inventory->user_email); ?>">
<input type="text" name="phone" value="<?php echo e($inventory->phone); ?>">
<input type="text" name="type" value="<?php echo e($inventory->type); ?>">
<input type="text" name="contact" value="<?php echo e($inventory->contact); ?>">
<input type="text" name="total" value="<?php echo e($inventory->total); ?>">
<input type="text" name="status" value="Processed">
            Account Name: 
            <input type="text" name="name" value="<?php echo e($inventory->name); ?>"  style="border:0; font-size:16px;width:350px;" readonly>

            Address: 
            <input type="text" name="address" value="<?php echo e($inventory->address); ?>"  style="border:0; font-size:16px;width:350px;" readonly>

        <table border="3" cellpadding="0" cellspacing="0" class="tabla">
        <tr>
        <th style=" background-color:#4CAF50;">Product</th>
        <th style=" background-color:#4CAF50;">END INV</th>
        <th style=" background-color:#4CAF50;">New Delivery</th>
        <th style=" background-color:#4CAF50;">DR/INV #</th>
        <th style=" background-color:#4CAF50;">Total Stocks</th>
        <th style=" background-color:#4CAF50;">Stocks On Hand</th>
        <th style=" background-color:#4CAF50;">Stocks Sold</th>
        <th style=" background-color:#4CAF50;">Price</th>
        <th style=" background-color:#4CAF50;">Amount</th>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;" name="product" value="<?php echo e($inventory->product); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="endinv" value="<?php echo e($inventory->totalstock); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel" value=""></td>
        <td><input type="text" style="border:0; font-size:16px;" name="invnum" value=""></td>
        <td><input type="number" style="border:0; font-size:16px;" name="totalstock" value=""></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stockleft" value=""></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stocksold" value=""></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price" value="<?php echo e($inventory->price); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="amount" value=""></td>
        </tr>

        <tr style=" background-color:white;">
        <td><input type="text" style="border:0; font-size:16px;" name="product2" value="<?php echo e($inventory->product2); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="endinv2" value="<?php echo e($inventory->stockleft2); ?>" readonly></td>
        <td><input type="number" style="border:0; font-size:16px;" name="newdel2" value=""></td>
        <td><input type="text" style="border:0; font-size:16px;" name="invnum2" value=""></td>
        <td><input type="number" style="border:0; font-size:16px;" name="totalstock2" value=""></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stockleft2" value=""></td>
        <td><input type="number" style="border:0; font-size:16px;" name="stocksold2" value=""></td>
        <td><input type="number" style="border:0; font-size:16px;" name="price2" value="<?php echo e($inventory->price2); ?>"></td>
        <td><input type="number" style="border:0; font-size:16px;" name="amount2" value=""></td>
        </tr>



        <tr>
        <th colspan="8" style="text-align:center;">Total:</th>
        <th></th>
        </tr>

        </table>
        

    <button type="submit" class="btn btn-primary">Save</button>
         
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\laravel-6-beginner\resources\views/newmonth/create.blade.php ENDPATH**/ ?>