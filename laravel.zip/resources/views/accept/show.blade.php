@extends('layouts.app')

@section('title', 'Deatails for ' . $purchase->name)

@section('content')
    <h1> Deatails for {{ $purchase->name }} </h1>

    
    


@endsection